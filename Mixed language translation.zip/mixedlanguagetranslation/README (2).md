# NLP-project-
it is about the mixed language translation to english 
